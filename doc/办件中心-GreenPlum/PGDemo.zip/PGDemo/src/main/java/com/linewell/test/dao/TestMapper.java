package com.linewell.test.dao;

import com.linewell.test.entity.Test;

/**
 * @author by mozping
 * @Classname PeopleMapper
 * @Description TODO
 * @Date 2019/5/9 19:25
 */
public interface TestMapper {

    Test selelctTest(String id);

    int addTest(Test people);

    int addTestGetId(Test people);

    int deleteById(String id);


    int updateById(String id);


}