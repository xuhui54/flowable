package com.linewell.test;

import com.linewell.test.dao.TestMapper;
import com.linewell.test.util.SqlSessionFactoryUtil;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

/**
 * @author by xuhui
 * @Classname Test02
 * @Description  GP连接测试
 * @Date 2019/9/18 15:00
 */
public class Test02 {

    private static final String CONFIG_FILE_PATH = "mybatis/postgresql-config.xml";

    @Test
    public void add() {
        SqlSession sqlSession = SqlSessionFactoryUtil.getSqlSessionFactoryInstaceByConfig(CONFIG_FILE_PATH).openSession();
        com.linewell.test.entity.Test test = new com.linewell.test.entity.Test();
        test.setId(System.currentTimeMillis()+"");
        test.setPermission_id("16392767785668608");
        TestMapper testMapper = sqlSession.getMapper(TestMapper.class);

        int rowAffected = testMapper.addTest(test);


        com.linewell.test.entity.Test test1= testMapper.selelctTest("77277780168937472");

        testMapper.updateById("16392767785668608");



        System.out.println("The rows be affected :" + rowAffected);
        System.out.println("The primary key is:" + test.getId());
        System.out.println("The primary test1 is:" + test1.getPermission_id());
        sqlSession.commit();
        SqlSessionFactoryUtil.closeSession(sqlSession);
    }

    @Test
    public void test1() {
        System.out.println(System.currentTimeMillis());
        System.out.println(System.currentTimeMillis() / 1000);

    }


}